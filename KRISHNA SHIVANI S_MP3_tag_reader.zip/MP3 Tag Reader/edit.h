#ifndef EDIT_H
#define EDIT_H

Story opening_files_edit(structure *structptr, FILE **fptr_dup);

Story copying_header(structure *structptr, FILE **fptr_dup);

Story little_endian_to_big(int *ptr);

Story copying_flag_encode(structure *structptr, FILE **fptr_dup);

Story editing_new_content(structure *structptr, FILE **fptr_dup, char *string);

Story copying_remaining_data(structure *structptr, FILE **fptr_dup);

Story editing_title(structure *structptr, FILE **fptr_dup, char *string);

Story editing_artist_name(structure *structptr, FILE **fptr_dup, char *string);

Story editing_album_name(structure *structptr, FILE **fptr_dup, char *string);

Story editing_year(structure *structptr, FILE **fptr_dup, char *string);

Story editing_content(structure *structptr, FILE **fptr_dup, char *string);

Story editing_comment(structure *structptr, FILE **fptr_dup, char *string);

Story edit(structure *structptr, FILE **fptr_dup, char *string, char *tag);


#endif