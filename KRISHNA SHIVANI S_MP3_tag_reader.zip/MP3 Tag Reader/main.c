/*
 * Project Title: MP3 TAG READER AND EDITOR
 * Name: KRISHNA SHIVANI S
 * Date: 02 JANUARY 2026
*/

#include <stdio.h>
#include <string.h>
#include "common.h"
#include "view.h"
#include "edit.h"

Story common_process(structure *, char flag);
Story open_mp3(structure *structptr);
Story open_mp3_for_edit(structure *structptr);
Story checking_if_mp3(structure *structptr);
Story checking_version(structure *structptr);
Story checking_extn(structure *structptr);


int main(int argc, char* argv[])
{

    if(argc <= 2 && strcmp(argv[1], "--help"))
    {
        printf("-----------------------------------------------------------------------------------------------\n");
        printf("ERROR: INVALID ARGUMENTS\n");
        printf("USAGE:\nTo view, pass arguments like: ./a.out -v <mp3filename>\n");
        printf("To edit, pass arguments like: ./a.out -e -t/-a/-A/-m/-y/-c changing_text <mp3filename>\n");
        printf("To get help, pass arguments like: ./a.out --help\n");
        printf("-----------------------------------------------------------------------------------------------\n");
    }

    if(argv[1] != NULL)
    {

        char *str = argv[1];

        if(!strcmp(str,"--help"))
        {
            printf("-----------------------------------------------------------------------------------------------\n");
            printf("                                       HELP MENU                  \n");
            printf("-----------------------------------------------------------------------------------------------\n");
            printf("1. -v -> to view mp3 file contents.\n");
            printf("2. -e -> to edit mp3 file contents.\n");
            printf("         2.1. -t -> to edit song title.\n");
            printf("         2.2. -a -> to edit artist name.\n");
            printf("         2.3. -A -> to edit album name.\n");
            printf("         2.4. -y -> to edit released year.\n");
            printf("         2.5. -m -> to edit content.\n");
            printf("         2.6. -c -> to edit comment.\n");
            printf("-----------------------------------------------------------------------------------------------\n");

        }
        else if(strlen(str) == 2)
        {
            
            switch(argv[1][1])
            {
                structure MP3;
                case 'v':
                
                    if(argv[2] != NULL && argc == 3)
                    {
                        MP3.mp3filename = argv[2];
                        if(common_process(&MP3, 0) == e_success)
                        {
                            do_viewing(&MP3);
                            view(&MP3);
                            free_everything(&MP3);
                        }
                    }
                    else
                    {
                        printf("-----------------------------------------------------------------------------------------------\n");
                        printf("ERROR: INVALID ARGUMENTS\n");
                        printf("USAGE:\nTo view, pass arguments like: ./a.out -v <mp3filename>\n");
                        printf("To edit, pass arguments like: ./a.out -e -t/-a/-A/-m/-y/-c changing_text <mp3filename>\n");
                        printf("To get help, pass arguments like: ./a.out --help\n");
                        printf("-----------------------------------------------------------------------------------------------\n");
                    }
                    break;

                case 'e':

                    if(argv[4] != NULL)
                    {
                        MP3.mp3filename = argv[4];
                        FILE *fptr_dup;
                        if(common_process(&MP3, 1) == e_success)
                        {
                            if(!strcmp(argv[2], "-t"))
                            {
                                if(editing_title(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing title completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else if(!strcmp(argv[2], "-a"))
                            {
                                if(editing_artist_name(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing artist name completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else if(!strcmp(argv[2], "-A"))
                            {
                                if(editing_album_name(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing album name completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else if(!strcmp(argv[2], "-y"))
                            {
                                if(editing_year(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing year completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else if(!strcmp(argv[2], "-m"))
                            {
                                if(editing_content(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing content completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else if(!strcmp(argv[2], "-c"))
                            {
                                if(editing_comment(&MP3, &fptr_dup, argv[3]) != e_failure)
                                {
                                    printf("INFO: Editing comment completed successfully.\nINFO: Saved as dup_%s\n", MP3.mp3filename);
                                }
                            }
                            else
                            {
                                printf("ERROR: Enter the correct arguments for editing.\n");
                                return e_failure;
                            }
                        }
                    }
                    break;
                default:
                    printf("-----------------------------------------------------------------------------------------------\n");
                    printf("ERROR: INVALID ARGUMENTS\n");
                    printf("USAGE:\nTo view, pass arguments like: ./a.out -v <mp3filename>\n");
                    printf("To edit, pass arguments like: ./a.out -e -t/-a/-A/-m/-y/-c changing_text <mp3filename>\n");
                    printf("To get help, pass arguments like: ./a.out --help\n");
                    printf("-----------------------------------------------------------------------------------------------\n");
                    break;
                
            }
        }

    }

}

Story common_process(structure *structptr, char flag)
{
    if(!flag)
    {
        if(open_mp3(structptr) != e_success)
        {
            printf("ERROR: Opening mp3 file failed\n");
            return e_failure;
        }
    }
    else
    {
        if(open_mp3_for_edit(structptr) != e_success)
        {
            printf("ERROR: Opening mp3 file failed\n");
            return e_failure;
        }
    }

    if(checking_if_mp3(structptr) != e_success)
    {
        printf("ERROR: The mentioned file is not an audio file.\n");
        return e_failure;
    }

    if(checking_version(structptr) != e_success)
    {
        printf("ERROR: Unable to check version.\n");
        return e_failure;
    }

    if(checking_extn(structptr) != e_success)
    {
        printf("ERROR: Unable to access extension.\n");
        return e_failure;
    }

    return e_success;

}

Story open_mp3(structure *structptr)
{

    structptr->fptr = fopen(structptr->mp3filename,"r");

    if(structptr->fptr == NULL)
    {
        perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", structptr->mp3filename);

        return e_failure;
    }

    return e_success;

}

Story open_mp3_for_edit(structure *structptr)
{

    structptr->fptr = fopen(structptr->mp3filename,"r+");

    if(structptr->fptr == NULL)
    {
        perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", structptr->mp3filename);

        return e_failure;
    }

    return e_success;

}

Story checking_if_mp3(structure *structptr)
{

    char buffer[3];

    fread(buffer,3,1,structptr->fptr);
    if(!strcmp(buffer,"ID3"))
        return e_success;
    else
        return e_failure;

}

Story checking_version(structure *structptr)
{

    char ch;

    fread(&ch,1,1,structptr->fptr);

    return e_success;

}

Story checking_extn(structure *structptr)
{

    char *arr[2] = {".mp3",".mpeg"};
    char *ptr = strchr(structptr->mp3filename,'.');

    for(int i = 0;i < 2;i++)
    {
        if(!(strcmp(arr[i],ptr)))
            return e_success;
    }

    return e_failure;

}