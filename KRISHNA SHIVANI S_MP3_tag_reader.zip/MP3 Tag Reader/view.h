#ifndef VIEW_H
#define VIEW_H

#include "common.h"

Story do_viewing(structure *structptr);

Story skip_header(structure *structptr);

void getting_tag(structure *structptr);

int getting_size(structure *structptr);

void getting_content(structure *structptr);

void view(structure *structptr);

void free_everything(structure *structptr);

#endif