#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "edit.h"

Story edit(structure *structptr, FILE **fptr_dup, char *string, char *tag_type)
{

    if(opening_files_edit(structptr, fptr_dup) != e_success)
    {
        printf("ERROR: Failed to open files for editing.\n");
        return e_failure;
    }

    if(copying_header(structptr, fptr_dup) != e_success)
    {
        printf("ERROR: Failed to copy the header.\n");
        return e_failure;
    }

    char tag[4];
    
        fread(&tag,4,1,structptr->fptr);

    while(strcmp(tag, tag_type))
    {
        fwrite(tag,1,4,*fptr_dup);

        int sizey;

        fread(&sizey,1,4,structptr->fptr);
        fwrite(&sizey,1,4,*fptr_dup);

        if(copying_flag_encode(structptr, fptr_dup) != e_success)
        {
            printf("ERROR: Unable to copy flag and encode bytes.\n");
            return e_failure;
        }

        little_endian_to_big(&sizey);    //size is getting converted from big to little endian
        
        char str[sizey-1];

        fread(str,1,sizey-1,structptr->fptr);
        fwrite(str,1,sizey-1,*fptr_dup);

        fread(tag,1,4,structptr->fptr);

    }

    if(!strcmp(tag,tag_type))
    {
        char i = 0;
        while(tag[i])
        {
            fputc(tag[i],*fptr_dup);
            i++;
        }
    }

    int size = strlen(string);
    size++;

    if(little_endian_to_big(&size) != e_success)    //size is changed to big endian format
    {
        printf("ERROR: Failed to convert the size from little endian to big endian.\n");
        return e_failure;
    }

    int old_size;

    fread(&old_size,1,4,structptr->fptr);   //Reading old size from original mp3 file
    little_endian_to_big(&old_size);    //Converting old size from big to little endian
    fwrite(&size,1,4,*fptr_dup);    //Writing the new size in big endian into the duplicate mp3 file

    if(copying_flag_encode(structptr, fptr_dup) != e_success)
    {
        printf("ERROR: Unable to copy flag and encode bytes.\n");
        return e_failure;
    }


    if(editing_new_content(structptr, fptr_dup, string) != e_success)   //In this function, string is added to the duplicate mp3 file
    {
        printf("ERROR: Unable to copy new title.\n");
        return e_failure;
    }

    fseek(structptr->fptr,old_size-1,SEEK_CUR);
    
    if(copying_remaining_data(structptr, fptr_dup) != e_success)
    {
        printf("ERROR: Unable to copy the remaining data.\n");
        return e_failure;
    }

    return e_success;

}

Story editing_title(structure *structptr, FILE **fptr_dup, char *string)
{
    
    edit(structptr, fptr_dup, string, "TIT2");

    return e_success;
    
}

Story editing_artist_name(structure *structptr, FILE **fptr_dup, char *string)
{

    edit(structptr, fptr_dup, string, "TPE1");

    return e_success;

}

Story editing_album_name(structure *structptr, FILE **fptr_dup, char *string)
{

    edit(structptr, fptr_dup, string, "TALB");

    return e_success;

}

Story editing_year(structure *structptr, FILE **fptr_dup, char *string)
{

    edit(structptr, fptr_dup, string, "TYER");

    return e_success;

}

Story editing_content(structure *structptr, FILE **fptr_dup, char *string)
{

    edit(structptr, fptr_dup, string, "TCON");

    return e_success;

}

Story editing_comment(structure *structptr, FILE **fptr_dup, char *string)
{

    edit(structptr, fptr_dup, string, "COMM");

    return e_success;

}

Story opening_files_edit(structure *structptr, FILE **fptr_dup)
{
    char new_filename[30];

    sprintf(new_filename, "dup_%s", structptr->mp3filename);

    *fptr_dup = fopen(new_filename, "wb");
    
    structptr->fptr = fopen(structptr->mp3filename, "r");

    if(structptr->fptr == NULL)
    {
        printf("ERROR: %s cannot be opened.\n", structptr->mp3filename);
        return e_failure;
    }
    
    return e_success;
}

Story copying_header(structure *structptr, FILE **fptr_dup)
{
    char buffer[10];

    fread(buffer,1,10,structptr->fptr);
    fwrite(buffer,1,10,*fptr_dup);
    
    return e_success;
}

Story little_endian_to_big(int *int_ptr)
{
    char temp, *ptr;

    ptr = (char *)int_ptr;

    temp = ptr[1];
    ptr[1] = ptr[2];
    ptr[2] = temp;

    temp = ptr[0];
    ptr[0] = ptr[3];
    ptr[3] = temp;

    return e_success;
}

Story copying_flag_encode(structure *structptr, FILE **fptr_dup)
{
    char buffer[3];

    fread(buffer,1,3,structptr->fptr);
    fwrite(buffer,1,3,*fptr_dup);

    return e_success;
}

Story editing_new_content(structure *structptr, FILE **fptr_dup, char *string)
{
    int i = 0;

    while(string[i])
    {
        fwrite(&string[i],1,1,*fptr_dup);
        i++;
    }

    return e_success;
}

Story copying_remaining_data(structure *structptr, FILE **fptr_dup)
{
    char ch;

    while(fread(&ch,1,1,structptr->fptr) > 0)
        fwrite(&ch,1,1,*fptr_dup);

    return e_success;
}