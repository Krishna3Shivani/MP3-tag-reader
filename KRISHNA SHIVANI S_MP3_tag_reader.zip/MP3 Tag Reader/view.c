#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "view.h"

Story do_viewing(structure *structptr)
{
    if(skip_header(structptr) != e_success)
    {
        printf("ERROR: Unable to skip header.\n");
        return e_failure;
    }


    for(int i = 0;i < 6;i++)        //We have 6 tags to find. So initiating a loop for 6 times
    {

        getting_tag(structptr);    //Getting the tag, 4 bytes

        int size = getting_size(structptr);     //Getting the size, 4 bytes

        if(!strcmp("TIT2", structptr->tag))
        {
            structptr->title = (char *)malloc(size);        //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->title,size - 1,1,structptr->fptr);
            structptr->title[size - 1] = '\0';
        }
        else if(!strcmp("TPE1", structptr->tag))
        {
            structptr->artist = (char *)malloc(size);       //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->artist,size - 1,1,structptr->fptr);
            structptr->artist[size - 1] = '\0';
        }
        else if(!strcmp("TALB", structptr->tag))
        {
            structptr->album = (char *)malloc(size);    //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->album,size - 1,1,structptr->fptr);
            structptr->album[size - 1] = '\0';
            
        }
        else if(!strcmp("TYER", structptr->tag))
        {
            structptr->year = (char *)malloc(size);         //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->year,size - 1,1,structptr->fptr);
            structptr->year[size - 1] = '\0';
        }
        else if(!strcmp("TCON", structptr->tag))
        {
            structptr->content = (char *)malloc(size);          //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->content,size - 1,1,structptr->fptr);
            structptr->content[size - 1] = '\0';
        }
        else if(!strcmp("COMM", structptr->tag))
        {
            structptr->comment = (char *)malloc(size);         //size - 1 for the contents and 1 for '\0'
            fseek(structptr->fptr,3,SEEK_CUR);      //Skipping the 2 flags and 1 encoding byte, which shows that the content is in ASCII

            fread(structptr->comment,size - 1,1,structptr->fptr);
            structptr->comment[size - 1] = '\0';
        }

    }

    return e_success;

}

void view(structure *structptr)
{
    printf("----------------------------------SELECTED VIEW DETAILS--------------------------------------------\n");

    printf("---------------------------------------------------------------------------------------------------\n");
    printf("                           MP3 TAG READER AND EDITOR FOR ID3v2\n");
    printf("---------------------------------------------------------------------------------------------------\n");

    printf("TITLE\t\t:\t\t%s\n", structptr->title);
    printf("ARTIST\t\t:\t\t%s\n", structptr->artist);
    printf("ALBUM\t\t:\t\t%s\n", structptr->album);
    printf("YEAR\t\t:\t\t%s\n", structptr->year);
    printf("CONTENT\t\t:\t\t%s\n", structptr->content);
    printf("COMMENT\t\t:\t\t%s\n", structptr->comment);
    printf("---------------------------------------------------------------------------------------------------\n");
}

Story skip_header(structure *structptr)
{

    fseek(structptr->fptr,10,SEEK_SET);
    return e_success;

}

void getting_tag(structure *structptr)
{
    fread(structptr->tag,4,1,structptr->fptr);
    structptr->tag[4] = '\0';
}

int getting_size(structure *structptr)
{

    int size;
    char temp,*ptr;

    fread(&size,4,1,structptr->fptr);

    ptr = (char *)&size;

    temp = ptr[0];
    ptr[0] = ptr[3];
    ptr[3] = temp;

    temp = ptr[2];
    ptr[2] = ptr[1];
    ptr[1] = temp;

    return size;

    
}

void free_everything(structure *structptr)
{
    free(structptr->title);
    free(structptr->artist);
    free(structptr->album);
    free(structptr->year);
    free(structptr->content);
    free(structptr->comment); 
}