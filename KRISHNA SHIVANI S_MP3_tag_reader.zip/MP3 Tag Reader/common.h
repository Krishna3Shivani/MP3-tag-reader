#ifndef COMMON_H
#define COMMON_H

typedef enum
{
    e_failure,
    e_success
}Story;

typedef struct MpThree
{

    char *mp3filename;  //mp3 file name
    FILE *fptr;     //Pointer for mp3 file
    char tag[5];    //Tag
    char *title;      //TIT2 -> Title / Song name
    char *artist;      //TPE1 -> Artist name
    char *album;      //TALB -> Album
    char *year;      //TYER -> Year it was released
    char *content;      //TCON -> Content type
    char *comment;      //COMM -> Comment

}structure;

#endif